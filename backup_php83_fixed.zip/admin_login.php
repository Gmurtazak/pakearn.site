<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
include('connection.php'); // Include your database connection file

// Login functionality
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $query = "SELECT * FROM admins WHERE email = '$email' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $_SESSION['admin'] = $email;
        header('Location: panal.php');
        exit();
    } else {
        $_SESSION['error'] = "Your email or password is wrong";
        header('Location: '.$_SERVER['PHP_SELF']);
        exit();
    }
}

// Forgot password functionality
if (isset($_POST['forgot_password'])) {
    $email = $_POST['email'];
    $secret_code = $_POST['secret_code'];

    $query = "SELECT * FROM admins WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        if ($row['secret_code'] === $secret_code) {
            $_SESSION['retrieved_password'] = $row['password'];
        } else {
            $_SESSION['error'] = "Sorry, your secret code is wrong";
        }
    } else {
        $_SESSION['error'] = "Email not found";
    }

    header('Location: '.$_SERVER['PHP_SELF']); // Refresh to prevent form resubmission
    exit();
}

// Display messages if they exist
$password_message = isset($_SESSION['retrieved_password']) ? "Your password is: " . $_SESSION['retrieved_password'] : null;
$error_message = isset($_SESSION['error']) ? $_SESSION['error'] : null;

// Clear session messages after displaying them
unset($_SESSION['retrieved_password']);
unset($_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="shortcut icon" type="x-icon" href="hum.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-container {
            background-color: #8E44AD;
            padding: 40px 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 350px;
            color: white;
        }
        .login-container h2 {
            margin-bottom: 20px;
            color: #ffffff;
        }
        .login-container input[type="email"], 
        .login-container input[type="password"], 
        .login-container input[type="text"] {
            width: 90%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
        }
        .login-container button {
            width: 100%;
            padding: 12px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }
        .login-container button:hover {
            background-color: #218838;
        }
        .login-container .error-message {
            background-color: #e74c3c;
            color: white;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 16px;
            font-weight: bold;
        }
        .logo {
    width: 100px; /* Adjust size as needed */
    height: 100px;
    border-radius: 50%;
    display: block;
    background:#fff;
    margin: 0 auto 20px; /* Center the logo and add space below it */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); /* Optional shadow for effect */
}

        .login-container .password-message {
            background-color: #28a745;
            color: white;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 18px;
            font-weight: bold;
        }
        .login-container .forgot-link {
            color: #ffffff;
            margin-top: 10px;
            display: block;
            cursor: pointer;
            text-decoration: underline;
        }
        .forgot-container {
            display: none;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <?php if ($password_message) { echo "<div class='password-message'>$password_message</div>"; } ?>
        <?php if ($error_message) { echo "<div class='error-message'>$error_message</div>"; } ?>
                <img src="hum.png" alt="Logo" class="logo">

        <h2>Admin Login</h2>
        <form method="POST" action="">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login">Login</button>
        </form>
        <span class="forgot-link" onclick="showForgotForm()">Forgot Password?</span>

        <div class="forgot-container" id="forgot-container">
            <h3>Forgot Password</h3>
            <form method="POST" action="">
                <input type="email" name="email" placeholder="Email" required>
                <input type="text" name="secret_code" placeholder="What is your Secret Code?" required>
                <button type="submit" name="forgot_password">Retrieve Password</button>
            </form>
        </div>
    </div>

    <script>
        function showForgotForm() {
            document.getElementById('forgot-container').style.display = 'block';
        }
    </script>
</body>
</html>
