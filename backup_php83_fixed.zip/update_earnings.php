<?php include $_SERVER['DOCUMENT_ROOT'] . '/../private/security.php'; ?>
<?php
include $_SERVER['DOCUMENT_ROOT'] . '/../private/unblock_earnings.php';

// Block common SQL injection attempts via GET parameters (case-insensitive)
$blacklist = ['select', 'insert', 'update', 'delete', 'drop', 'truncate', 'alter', '--', ';', '/*', '*/', '@@', '@', 'exec', '1=1'];

foreach ($_GET as $param => $value) {
    if (is_array($value)) continue;

    $value = strtolower($value); // convert input to lowercase

    foreach ($blacklist as $word) {
        if (strpos($value, $word) !== false) {
            http_response_code(403);
            exit("Blocked: Malicious keyword '$word' detected in URL.");
        }
    }
}
?>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/connection.php';
date_default_timezone_set('Asia/Karachi');

$id = $_POST['id'];
$ads_earning = $_POST['ads_earning'];
$box = $_POST['box']; // Which box (box1, box2, etc.) is being clicked

// Fetch level from the level table
$result = $conn->query("SELECT level FROM level WHERE us_id = $id");
if (!$result || $result->num_rows == 0) {
    die(json_encode(['success' => false, 'error' => "Error fetching level or no level found"]));
}
$row = $result->fetch_assoc();
$level = $row['level'];

// Fetch price from the plan table
$result = $conn->query("SELECT price FROM plan WHERE user_id = '$id'");
if (!$result || $result->num_rows == 0) {
    die(json_encode(['success' => false, 'error' => "Error fetching price or no price found"]));
}
$row = $result->fetch_assoc();
$price = $row['price'];

// Fetch base and reward_increment from the price_values table
$result = $conn->query("SELECT base, reward_increment FROM price_values WHERE price = '$price'");
if (!$result || $result->num_rows == 0) {
    die(json_encode(['success' => false, 'error' => "Error fetching base or reward_increment"]));
}
$row = $result->fetch_assoc();
$base = $row['base'];
$re = $row['reward_increment'];

$ads_increment = 0;
$total_earn = 0;
$reward_increment = 0;

// Handle level 10 separately
if ($level == 10) {
    // For level 10, set earnings to 900 per box
    $total_earn = 900;
    $ads_earning += 900;
    $reward_increment = 0;
} else {
    // For levels 1 to 9, use the existing logic
    if ($level >= 1 && $level <= 9) {
        $ads_increment = ($base - 1) + $level;
        $total_earn = $base + ($level - 1) * 2;
        $reward_increment = $re + ($level - 1) * 10;
        $ads_earning += $ads_increment;
    } else {
        die(json_encode(['success' => false, 'error' => "Invalid level detected. Level must be between 1 and 10."]));
    }
}

// ✅ STEP 1: Get old balance BEFORE earnings update
$old_balance = 0;
$getOld = $conn->query("SELECT total_earning FROM earnings WHERE id = '$id'");
if ($getOld && $getOld->num_rows > 0) {
    $rowOld = $getOld->fetch_assoc();
    $old_balance = $rowOld['total_earning'];
}

// ✅ Your original code STARTS here (DO NOT change anything below till notify part)
$result = $conn->query("SELECT id FROM earnings WHERE id = '$id'");
if ($result && $result->num_rows > 0) {
    $stmt = $conn->prepare("UPDATE earnings SET total_earning = total_earning + ?, ads_earning = ? WHERE id = ?");
    $stmt->bind_param("isi", $total_earn, $ads_earning, $id);
    $stmt->execute();
    if ($stmt->error) {
        die(json_encode(['success' => false, 'error' => "Error updating earnings: " . $stmt->error]));
    }
} else {
    $stmt = $conn->prepare("INSERT INTO earnings (id, total_earning, ads_earning) VALUES (?, ?, ?)");
    $stmt->bind_param("iis", $id, $total_earn, $ads_earning);
    $stmt->execute();
    if ($stmt->error) {
        die(json_encode(['success' => false, 'error' => "Error inserting earnings: " . $stmt->error]));
    }
}

$stmt = $conn->prepare("UPDATE level SET reward = reward + ? WHERE us_id = ?");
$stmt->bind_param("ii", $reward_increment, $id);
$stmt->execute();
if ($stmt->error) {
    die(json_encode(['success' => false, 'error' => "Error updating rewards: " . $stmt->error]));
}

$stmt = $conn->prepare("UPDATE records SET $box = 0 WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
if ($stmt->error) {
    die(json_encode(['success' => false, 'error' => "Error updating records table: " . $stmt->error]));
}

// ✅ STEP 2: Now get the updated (new) balance
$new_balance = 0;
$getNew = $conn->query("SELECT total_earning FROM earnings WHERE id = '$id'");
if ($getNew && $getNew->num_rows > 0) {
    $rowNew = $getNew->fetch_assoc();
    $new_balance = $rowNew['total_earning'];
}

// ✅ STEP 3: Insert into notify
$total_add = $new_balance - $old_balance;
$created_at = date("Y-m-d H:i:s");
$message = "earned from $box";

$stmt = $conn->prepare("INSERT INTO notify (user_id, name, message, old_earn, total_add, current_earn, created_at)
                        VALUES (?, NULL, ?, ?, ?, ?, ?)");
$stmt->bind_param("isiiis", $id, $message, $old_balance, $total_add, $new_balance, $created_at);
$stmt->execute();
if ($stmt->error) {
    die(json_encode(['success' => false, 'error' => "Error inserting into notify: " . $stmt->error]));
}
echo json_encode(['success' => true]);
include $_SERVER['DOCUMENT_ROOT'] . '/../private/block_earnings.php';

$conn->close();
?>