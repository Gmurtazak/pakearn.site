<?php
/**
 * PHP 8.3 compatible database connection for CloudPanel.
 * This file must stay in the website document root:
 * /home/pakearn/htdocs/pakearn.site/connection.php
 */

$servername = '127.0.0.1';
$username   = 'main1';
$password   = 'r0SqPKY4ZmRuTPsm6Doz';
$dbname     = 'main1';

mysqli_report(MYSQLI_REPORT_OFF);

$conn = new mysqli($servername, $username, $password, $dbname, 3306);

if ($conn->connect_errno) {
    http_response_code(500);
    die('Database connection failed: ' . htmlspecialchars($conn->connect_error ?? 'Unknown error', ENT_QUOTES, 'UTF-8'));
}

$conn->set_charset('utf8mb4');

// Compatibility aliases for old files, if any file uses a different variable name.
$mysqli = $conn;
$con = $conn;
$db = $conn;
?>
