<?php
/**
 * Redirect from pakearn.io to pakearn.net while preserving the path and parameters.
 */

$current_host = $_SERVER['HTTP_HOST'];
$request_uri = $_SERVER['REQUEST_URI'];

// Check if the current host contains pakearn.io
if (strpos($current_host, 'pakearn.io') !== false) {
    // Construct the new URL on pakearn.net
    $new_url = 'https://pakearn.net' . $request_uri;
    
    // Perform a 301 Permanent Redirect
    header("HTTP/1.1 301 Moved Permanently");
    header("Location: " . $new_url);
    exit();
}
?>
