<?php
$servername = "localhost ";
$username = "u412516437_lucky786668";
$password = "Lucky786668@205";
$dbname = "u412516437_reg";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>